<?php
require_once '../models/Expense.php';
require_once '../models/Category.php'; // Ensure Category model is included

class ExpenseController {
    private function startSessionIfNotActive() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
            header("Location: /login");
            exit();
        }
    }

    public function listExpenses() {
        $this->startSessionIfNotActive();
        $role = $_SESSION['role'];
        $userId = $_SESSION['user_id'];

        // Fetch expenses based on role
        $expenses = ($role === 'admin') 
                    ? Expense::getAllExpenses() 
                    : Expense::getUserExpenses($userId);

        // Fetch categories for dropdown and mapping
        $categories = ($role === 'admin') 
                      ? Category::getAllCategories() 
                      : Category::getUserCategories($userId);

        // Create a map of category_id => category_name for display
        $categoriesMap = [];
        foreach ($categories as $category) {
            $categoriesMap[$category['id']] = $category['name'];
        }

        $editExpense = null;

        // Check if editing an expense
        if (isset($_GET['id'])) {
            $editExpense = ($role === 'admin') 
                           ? Expense::findById($_GET['id']) 
                           : Expense::findByIdAndUser($_GET['id'], $userId);

            if (!$editExpense) {
                die("Expense not found or access denied!");
            }
        }

        // Pass data to the view
        require '../views/expenses.php';
    }

    public function storeExpense() {
        $this->startSessionIfNotActive();
        $userId = $_SESSION['user_id'];

        // Log raw POST data for debugging
        error_log("Submitted POST data: " . print_r($_POST, true));

        // Validation
        if (
            !isset($_POST['category_id'], $_POST['amount'], $_POST['transaction_date']) || 
            $_POST['category_id'] === '' || 
            $_POST['amount'] === '' || 
            $_POST['transaction_date'] === ''
        ) {
            die("Category, amount, and transaction date are required!");
        }

        // Sanitize and prepare input
        $categoryId = (int)$_POST['category_id'];
        $amount = (float)$_POST['amount'];
        $description = !empty($_POST['description']) ? trim($_POST['description']) : null;
        $transactionDate = trim($_POST['transaction_date']);

        // Log sanitized inputs
        error_log("Sanitized data: category_id={$categoryId}, amount={$amount}, transaction_date={$transactionDate}, description={$description}");

        // Validate category access
        $role = $_SESSION['role'];
        $category = ($role === 'admin') 
                    ? Category::findById($categoryId) 
                    : Category::findByIdAndUser($categoryId, $userId);

        if (!$category) {
            die("Invalid category selected!");
        }

        // Save expense
        $expense = new Expense($userId, $categoryId, $amount, $description, $transactionDate);
        if ($expense->save()) {
            header("Location: /expenses");
        } else {
            echo "Error adding expense.";
        }
    }

    public function updateExpense() {
        $this->startSessionIfNotActive();

        // Validate inputs
        if (empty($_POST['id']) || empty($_POST['category_id']) || empty($_POST['amount']) || empty($_POST['transaction_date'])) {
            die("ID, category, amount, and transaction date are required!");
        }

        $id = $_POST['id'];
        $categoryId = $_POST['category_id'];
        $amount = $_POST['amount'];
        $description = $_POST['description'] ?? null;
        $transactionDate = $_POST['transaction_date'];
        $role = $_SESSION['role'];
        $userId = $_SESSION['user_id'];

        // Check permissions
        $expense = ($role === 'admin') 
                   ? Expense::findById($id) 
                   : Expense::findByIdAndUser($id, $userId);

        if (!$expense) {
            die("Expense not found or access denied!");
        }

        // Update expense
        if (Expense::update($id, $categoryId, $amount, $description, $transactionDate)) {
            header("Location: /expenses");
        } else {
            echo "Error updating expense.";
        }
    }

    public function deleteExpense() {
        $this->startSessionIfNotActive();

        // Validate ID
        if (empty($_GET['id'])) {
            die("Expense ID is required!");
        }

        $id = $_GET['id'];
        $role = $_SESSION['role'];
        $userId = $_SESSION['user_id'];

        // Check permissions
        $expense = ($role === 'admin') 
                   ? Expense::findById($id) 
                   : Expense::findByIdAndUser($id, $userId);

        if (!$expense) {
            die("Expense not found or access denied!");
        }

        // Delete expense
        if (Expense::delete($id)) {
            header("Location: /expenses");
        } else {
            echo "Error deleting expense.";
        }
    }
}
?>
