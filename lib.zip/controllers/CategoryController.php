<?php
require_once '../models/Category.php';

class CategoryController {
    // Ensure session is active and user is authenticated
    private function startSessionIfNotActive() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Ensure the user is logged in
        if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
            header("Location: /login");
            exit();
        }
    }

    // List categories
    public function listCategories() {
        $this->startSessionIfNotActive();
        $role = $_SESSION['role'];
        $userId = $_SESSION['user_id'];
    
        // Fetch categories based on user role
        $categories = ($role === 'admin') 
                      ? Category::getAllCategories() 
                      : Category::getUserCategories($userId);

        $editCategory = null;

        if (isset($_GET['id'])) {
            $editCategory = ($role === 'admin') 
                            ? Category::findById($_GET['id']) 
                            : Category::findByIdAndUser($_GET['id'], $userId);

            if (!$editCategory) {
                die("Category not found or access denied!");
            }
        }

        require '../views/categories.php';
    }

    // Store a new category
    public function storeCategory() {
        $this->startSessionIfNotActive();
        $userId = $_SESSION['user_id'];

        // Validate inputs
        if (empty($_POST['name']) || empty($_POST['color'])) {
            die("Name and color are required!");
        }

        $name = trim($_POST['name']);
        $color = trim($_POST['color']);

        $category = new Category($userId, $name, $color);
        if ($category->save()) {
            header("Location: /categories");
        } else {
            echo "Error adding category.";
        }
    }

    // Update an existing category
    public function updateCategory() {
        $this->startSessionIfNotActive();

        // Validate inputs
        if (empty($_POST['id']) || empty($_POST['name']) || empty($_POST['color'])) {
            die("ID, name, and color are required!");
        }

        $id = (int) $_POST['id'];
        $name = trim($_POST['name']);
        $color = trim($_POST['color']);
        $role = $_SESSION['role'];
        $userId = $_SESSION['user_id'];

        // Fetch the category
        $category = ($role === 'admin') 
                    ? Category::findById($id) 
                    : Category::findByIdAndUser($id, $userId);

        if (!$category) {
            die("Category not found or access denied!");
        }

        // Update the category
        if (Category::update($id, $name, $color)) {
            header("Location: /categories");
        } else {
            echo "Error updating category.";
        }
    }

    // Delete an existing category
    public function deleteCategory() {
        $this->startSessionIfNotActive();
    
        // Validate ID
        if (empty($_GET['id'])) {
            die("Category ID is required!");
        }
    
        $id = (int) $_GET['id'];
        $role = $_SESSION['role'];
        $userId = $_SESSION['user_id'];
    
        // Fetch the category
        $category = ($role === 'admin') 
                    ? Category::findById($id) 
                    : Category::findByIdAndUser($id, $userId);
    
        if (!$category) {
            die("Category not found or access denied!");
        }
    
        // Check for associated transactions
        if (Expense::countByCategory($id) > 0) {
            echo "<script>
                    alert('Category cannot be deleted as it has associated transactions.');
                    window.location.href = '/categories';
                  </script>";
            exit();
        }
    
        // Proceed with deletion
        if (Category::delete($id)) {
            header("Location: /categories");
        } else {
            echo "<script>
                    alert('Error deleting category. Please try again.');
                    window.location.href = '/categories';
                  </script>";
        }
    }
    
}
?>
