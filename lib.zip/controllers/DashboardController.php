<?php
require_once '../models/User.php';
require_once '../models/Category.php';
require_once '../models/Expense.php';

class DashboardController {
    public function showDashboard() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION['user_id'])) {
            header("Location: /login");
            exit();
        }

        $role = $_SESSION['role'];
        $userId = $_SESSION['user_id'];

        if ($role === 'admin') {
            $data = [
                'role' => 'admin',
                'totalUsers' => User::getTotalUsers(),
                'totalCategories' => Category::getTotalCategories(),
                'totalExpenses' => Expense::getTotalExpensesAmount(true), // Admin-wide total
                'chartData' => Expense::getExpensesGroupedByCategory(true), // Admin-wide grouped data
            ];
        } else {
            $data = [
                'role' => 'user',
                'totalCategories' => Category::getUserCategoriesCount($userId),
                'totalExpenses' => Expense::getTotalExpensesAmount(false, $userId),
                'recentExpenses' => Expense::getUserRecentExpenses($userId), // Fetch recent expenses
                'chartData' => Expense::getUserExpensesGroupedByCategory($userId), // User-specific chart data
            ];            
        }

        require '../views/dashboard.php';
    }
}
?>
