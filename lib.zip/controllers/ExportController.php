<?php
require_once '../models/Expense.php';
require_once '../models/ExportLog.php';
require_once '../models/Category.php';
require_once '../lib/fpdf.php'; // Include FPDF for PDF generation

class ExportController {
    private function startSessionIfNotActive() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
            header("Location: /login");
            exit();
        }
    }

    // Fetch data for export
    private function fetchExportData($userId, $isAdmin) {
        global $pdo;

        if ($isAdmin) {
            $query = "SELECT 
                          t.id, 
                          u.username AS user_name, 
                          c.name AS category_name, 
                          t.amount, 
                          t.description, 
                          t.transaction_date 
                      FROM transactions t
                      LEFT JOIN users u ON t.user_id = u.id
                      LEFT JOIN categories c ON t.category_id = c.id
                      WHERE t.deleted_at IS NULL";
            $stmt = $pdo->query($query);
        } else {
            $query = "SELECT 
                          t.id, 
                          c.name AS category_name, 
                          t.amount, 
                          t.description, 
                          t.transaction_date 
                      FROM transactions t
                      LEFT JOIN categories c ON t.category_id = c.id
                      WHERE t.user_id = :user_id AND t.deleted_at IS NULL";
            $stmt = $pdo->prepare($query);
            $stmt->execute([':user_id' => $userId]);
        }

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Generate CSV
    private function generateCSV($data, $filename = 'export.csv') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment;filename=' . $filename);

        $output = fopen('php://output', 'w');

        if (!empty($data)) {
            fputcsv($output, array_keys($data[0])); // Headers
            foreach ($data as $row) {
                fputcsv($output, $row); // Data
            }
        }

        fclose($output);
    }

    // Generate PDF
    private function generatePDF($data, $filename = 'export.pdf') {
        require_once '../lib/fpdf.php';
        $pdf = new FPDF();
        $pdf->AddPage();
        
        // Set Title
        $pdf->SetFont('Arial', 'B', 16);
        $pdf->Cell(0, 10, 'Expense Report', 0, 1, 'C');
        $pdf->Ln(10); // Add space below the title
    
        // Set Header
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->SetFillColor(200, 200, 200); // Light gray background for header
        $headers = array_keys($data[0]);
        foreach ($headers as $header) {
            $pdf->Cell(40, 10, $header, 1, 0, 'C', true); // Add padding and center align
        }
        $pdf->Ln();
    
        // Set Data Rows
        $pdf->SetFont('Arial', '', 12);
        foreach ($data as $row) {
            foreach ($row as $cell) {
                $pdf->Cell(40, 10, $cell, 1, 0, 'C'); // Add padding and center align
            }
            $pdf->Ln();
        }
    
        // Output the PDF
        $pdf->Output('D', $filename);
    }
    

    // Export functionality
    public function export($format) {
        $this->startSessionIfNotActive();
        $userId = $_SESSION['user_id'];
        $role = $_SESSION['role'];

        $isAdmin = ($role === 'admin');
        $data = $this->fetchExportData($userId, $isAdmin);

        // Log export operation
        $log = new ExportLog($userId, $format);
        $log->save();

        // Generate file
        if ($format === 'CSV') {
            $this->generateCSV($data, 'expenses_export.csv');
        } elseif ($format === 'PDF') {
            $this->generatePDF($data, 'expenses_export.pdf');
        } else {
            die('Invalid export format.');
        }
    }
}
?>
