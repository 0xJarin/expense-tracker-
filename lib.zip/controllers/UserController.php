<?php
require_once '../models/User.php';

class UserController {
    private function startSessionIfNotActive() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    public function showLogin() {
        require '../views/login.php';
    }

    public function showRegister() {
        require '../views/register.php';
    }

    public function login() {
        $this->startSessionIfNotActive();
        $username = $_POST['username'];
        $password = $_POST['password'];

        $user = User::findByUsername($username);
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            header("Location: /dashboard");
        } else {
            $_SESSION['login_error'] = "Invalid username or password.";
            header("Location: /login");
        }
    }

    public function logout() {
        $this->startSessionIfNotActive();
        session_unset();
        session_destroy();
        header("Location: /login");
    }

    public function register() {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $confirmPassword = $_POST['confirm_password'];
        $role = $_POST['role'];

        if ($password !== $confirmPassword) {
            die("Passwords do not match!");
        }

        if (!in_array($role, ['user', 'admin'])) {
            die("Invalid role selected!");
        }

        if (User::findByUsername($username)) {
            die("Username already exists!");
        }

        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $user = new User($username, $email, $hashedPassword, $role);

        if ($user->save()) {
            header("Location: /login");
        } else {
            echo "Error during registration.";
        }
    }

    public function listUsers($params = []) {
        $this->startSessionIfNotActive();
        if ($_SESSION['role'] !== 'admin') {
            redirectTo('/dashboard');
        }
    
        $users = User::getAllUsers();
        $editUser = null;
    
        // Check if an edit ID is provided and fetch the user for editing
        if (isset($params['edit_id'])) {
            $editUser = User::findById($params['edit_id']);
            if (!$editUser) {
                die("User not found!");
            }
        }
    
        require '../views/users.php'; // Pass $editUser to the view for rendering
    }
    

    public function storeUser() {
        $this->startSessionIfNotActive();
        if ($_SESSION['role'] !== 'admin') {
            header("Location: /dashboard");
            exit();
        }

        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $role = $_POST['role'];

        if (!in_array($role, ['user', 'admin'])) {
            die("Invalid role selected!");
        }

        if (User::findByUsername($username)) {
            echo "Error: Username already exists.";
            return;
        }

        $user = new User($username, $email, $password, $role);
        if ($user->save()) {
            header("Location: /users");
        } else {
            echo "Error adding user.";
        }
    }
    public function editUser() {
        $this->startSessionIfNotActive();
        if (!isAdmin()) redirectTo('/dashboard');
    
        $id = $_GET['id'] ?? null;
        if (!$id) {
            die("User ID is required.");
        }
    
        $editUser = User::findById($id);
        if (!$editUser) {
            die("User not found!");
        }
    
        $users = User::getAllUsers(); // To list all users in the same view
        require '../views/users.php'; // Load the unified user management view
    }
    
    public function updateUser() {
        $this->startSessionIfNotActive();
        if ($_SESSION['role'] !== 'admin') {
            header("Location: /dashboard");
            exit();
        }

        $id = $_POST['id'];
        $username = $_POST['username'];
        $email = $_POST['email'];
        $role = $_POST['role'];

        if (!in_array($role, ['user', 'admin'])) {
            die("Invalid role selected!");
        }

        if (User::update($id, $username, $email, $role)) {
            header("Location: /users");
        } else {
            echo "Error updating user.";
        }
    }

    public function deleteUser() {
        $this->startSessionIfNotActive();
        if ($_SESSION['role'] !== 'admin') {
            header("Location: /dashboard");
            exit();
        }

        $id = $_GET['id'];
        if (User::delete($id)) {
            header("Location: /users");
        } else {
            echo "Error deleting user.";
        }
    }
}
?>
