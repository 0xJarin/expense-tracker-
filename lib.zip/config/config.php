<?php
// Load environment variables
$env = [
    'APP_ENV' => 'development',
    'DB_DSN' => 'mysql:host=localhost;dbname=expense_tracks',
    'DB_USERNAME' => 'root',
    'DB_PASSWORD' => 'pass4sql',
];

// Check the environment
if ($env['APP_ENV'] === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Database connection
try {
    $pdo = new PDO($env['DB_DSN'], $env['DB_USERNAME'], $env['DB_PASSWORD']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}
?>
