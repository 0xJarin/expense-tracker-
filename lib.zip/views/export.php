<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Export Transactions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        .header {
            background-color: #4CAF50;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 {
            margin: 0;
            font-size: 20px;
        }
        .header a {
            color: white;
            text-decoration: none;
            background: #333;
            padding: 10px 15px;
            border-radius: 5px;
        }
        .header a:hover {
            background: #555;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            background: #fff;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        h2 {
            font-size: 20px;
            margin-bottom: 20px;
            color: #333;
        }
        p {
            margin-bottom: 20px;
        }
        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 10px;
        }
        button:hover {
            background-color: #45a049;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: 1px solid #ddd;
            text-align: left;
            padding: 12px;
        }
        th {
            background-color: #f2f2f2;
        }
        .empty-state {
            text-align: center;
            color: #888;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Export Transactions</h1>
        <a href="/dashboard">Back to Dashboard</a>
    </div>

    <div class="container">
        <h2>Export Options</h2>
        <p>Select a format to export your transactions:</p>
        <form action="/export/csv" method="GET" style="display: inline-block;">
            <button type="submit">Export as CSV</button>
        </form>
        <form action="/export/pdf" method="GET" style="display: inline-block;">
            <button type="submit">Export as PDF</button>
        </form>

        <h2>Export Logs</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Format</th>
                    <th>Export Date</th>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <th>User</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($exportLogs)): ?>
                    <tr>
                        <td colspan="<?= ($_SESSION['role'] === 'admin') ? '4' : '3' ?>" class="empty-state">No export logs found.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($exportLogs as $log): ?>
                        <tr>
                            <td><?= htmlspecialchars($log['id']) ?></td>
                            <td><?= htmlspecialchars($log['format']) ?></td>
                            <td><?= htmlspecialchars($log['export_date']) ?></td>
                            <?php if ($_SESSION['role'] === 'admin'): ?>
                                <td><?= htmlspecialchars($log['username']) ?></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
