<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f9;
            color: #333;
        }

        .container {
            max-width: 1000px;
            margin: 20px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h1, h2 {
            text-align: center;
            color: #4CAF50;
        }

        form {
            margin: 20px auto;
            max-width: 500px;
            background: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        form label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        form input[type="text"],
        form input[type="email"],
        form input[type="password"],
        form select,
        form button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        form button {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }

        form button:hover {
            background-color: #45a049;
        }

        form a {
            display: inline-block;
            margin-top: 10px;
            text-decoration: none;
            color: #555;
        }

        form a:hover {
            color: #4CAF50;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        table th {
            background-color: #4CAF50;
            color: white;
        }

        table td a {
            text-decoration: none;
            color: #4CAF50;
            padding: 5px 10px;
            border: 1px solid #4CAF50;
            border-radius: 5px;
        }

        table td a:hover {
            background-color: #4CAF50;
            color: white;
        }

        .empty-state {
            text-align: center;
            color: #888;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Manage Users</h1>

        <!-- Add/Edit User Form -->
        <h2><?= isset($editUser) ? 'Edit User' : 'Add New User' ?></h2>
<form action="<?= isset($editUser) ? '/users/update' : '/users/store' ?>" method="POST">
    <?php if (isset($editUser)): ?>
        <input type="hidden" name="id" value="<?= htmlspecialchars($editUser['id']) ?>">
    <?php endif; ?>
    <label for="username">Username:</label>
    <input type="text" id="username" name="username" value="<?= isset($editUser) ? htmlspecialchars($editUser['username']) : '' ?>" required>

    <label for="email">Email:</label>
    <input type="email" id="email" name="email" value="<?= isset($editUser) ? htmlspecialchars($editUser['email']) : '' ?>" required>

    <?php if (!isset($editUser)): ?>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
    <?php endif; ?>

    <label for="role">Role:</label>
    <select id="role" name="role" required>
        <option value="user" <?= isset($editUser) && $editUser['role'] === 'user' ? 'selected' : '' ?>>User</option>
        <option value="admin" <?= isset($editUser) && $editUser['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
    </select>

    <button type="submit"><?= isset($editUser) ? 'Update User' : 'Add User' ?></button>
    <?php if (isset($editUser)): ?>
        <a href="/users">Cancel</a>
    <?php endif; ?>
</form>


        <!-- Display Users -->
        <h2>All Users</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($users)): ?>
                    <tr>
                        <td colspan="5" class="empty-state">No users found.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?= htmlspecialchars($user['id']) ?></td>
                            <td><?= htmlspecialchars($user['username']) ?></td>
                            <td><?= htmlspecialchars($user['email']) ?></td>
                            <td><?= htmlspecialchars($user['role']) ?></td>
                            <td>
                                <a href="/users/edit?id=<?= htmlspecialchars($user['id']) ?>">Edit</a>
                                <a href="/users/delete?id=<?= htmlspecialchars($user['id']) ?>" onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
