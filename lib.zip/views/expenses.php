<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expenses</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
        }
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #4CAF50;
            color: white;
            padding: 15px 20px;
            border-radius: 8px 8px 0 0;
        }
        .header h1 {
            margin: 0;
        }
        .header a {
            text-decoration: none;
            color: white;
            background: #333;
            padding: 10px 15px;
            border-radius: 5px;
        }
        .header a:hover {
            background: #555;
        }
        form {
            margin-top: 20px;
            background: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        label {
            font-weight: bold;
        }
        input, select, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: 1px solid #ddd;
            text-align: left;
            padding: 12px;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:hover {
            background-color: #f9f9f9;
        }
        a {
            text-decoration: none;
            color: #007BFF;
        }
        a:hover {
            text-decoration: underline;
        }
        .empty-state {
            text-align: center;
            color: #888;
            font-style: italic;
        }
        .back-button {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: white;
            background: #333;
            padding: 10px 15px;
            border-radius: 5px;
        }
        .back-button:hover {
            background: #555;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Expenses</h1>
            <a href="/dashboard">Back to Dashboard</a>
        </div>

        <!-- Add/Edit Expense Form -->
        <h2><?= isset($editExpense) ? 'Edit Expense' : 'Add New Expense' ?></h2>
        <form action="<?= isset($editExpense) ? '/expenses/update' : '/expenses/store' ?>" method="POST">
            <?php if (isset($editExpense)): ?>
                <input type="hidden" name="id" value="<?= htmlspecialchars($editExpense['id']) ?>">
            <?php endif; ?>
            <label for="category_id">Category:</label>
            <select id="category_id" name="category_id" required>
                <option value="">Select a category</option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?= htmlspecialchars($category['id']) ?>" <?= isset($editExpense) && $editExpense['category_id'] == $category['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($category['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <label for="amount">Amount:</label>
            <input type="number" id="amount" name="amount" value="<?= isset($editExpense) ? htmlspecialchars($editExpense['amount']) : '' ?>" required>
            <label for="description">Description:</label>
            <textarea id="description" name="description"><?= isset($editExpense) ? htmlspecialchars($editExpense['description']) : '' ?></textarea>
            <label for="transaction_date">Transaction Date:</label>
            <input type="date" id="transaction_date" name="transaction_date" value="<?= isset($editExpense) ? htmlspecialchars($editExpense['transaction_date']) : '' ?>" required>
            <button type="submit"><?= isset($editExpense) ? 'Update Expense' : 'Add Expense' ?></button>
            <?php if (isset($editExpense)): ?>
                <a href="/expenses" class="back-button">Cancel</a>
            <?php endif; ?>
        </form>

        <!-- List Expenses -->
        <h2>All Expenses</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Category</th>
                    <th>Amount</th>
                    <th>Description</th>
                    <th>Transaction Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($expenses)): ?>
                    <tr>
                        <td colspan="6" class="empty-state">No expenses found.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($expenses as $expense): ?>
                        <tr>
                            <td><?= htmlspecialchars($expense['id']) ?></td>
                            <td><?= htmlspecialchars($categoriesMap[$expense['category_id']] ?? 'Unknown') ?></td>
                            <td>¥<?= htmlspecialchars(number_format($expense['amount'], 2)) ?></td>
                            <td><?= htmlspecialchars($expense['description']) ?></td>
                            <td><?= htmlspecialchars($expense['transaction_date']) ?></td>
                            <td>
                                <a href="/expenses?id=<?= htmlspecialchars($expense['id']) ?>">Edit</a>
                                <a href="/expenses/delete?id=<?= htmlspecialchars($expense['id']) ?>" onclick="return confirm('Are you sure you want to delete this expense?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
