<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categories</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h1, h2 {
            text-align: center;
            color: #4CAF50;
        }

        form {
            margin: 20px auto;
            max-width: 500px;
            background: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        form label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        form input[type="text"],
        form input[type="color"],
        form button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        form button {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }

        form button:hover {
            background-color: #45a049;
        }

        form a {
            display: inline-block;
            margin-top: 10px;
            text-decoration: none;
            color: #555;
        }

        form a:hover {
            color: #4CAF50;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        table th {
            background-color: #4CAF50;
            color: white;
        }

        table td {
            background-color: #fff;
        }

        table td a {
            text-decoration: none;
            color: #4CAF50;
            padding: 5px 10px;
            border: 1px solid #4CAF50;
            border-radius: 5px;
        }

        table td a:hover {
            background-color: #4CAF50;
            color: white;
        }

        .color-preview {
            width: 50px;
            height: 20px;
            display: inline-block;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .back-button {
            display: inline-block;
            margin: 20px;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
        }

        .back-button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="/dashboard" class="back-button">&larr; Back to Dashboard</a>
        <h1>Categories</h1>

        <!-- Add/Edit Category Form -->
        <h2><?= isset($editCategory) ? 'Edit Category' : 'Add New Category' ?></h2>
        <form action="<?= isset($editCategory) ? '/categories/update' : '/categories/store' ?>" method="POST">
            <?php if (isset($editCategory)): ?>
                <input type="hidden" name="id" value="<?= $editCategory['id'] ?>">
            <?php endif; ?>
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?= isset($editCategory) ? $editCategory['name'] : '' ?>" required>

            <label for="color">Color:</label>
            <input type="color" id="color" name="color" value="<?= isset($editCategory) ? $editCategory['color'] : '#FFFFFF' ?>" required>

            <button type="submit"><?= isset($editCategory) ? 'Update Category' : 'Add Category' ?></button>
            <?php if (isset($editCategory)): ?>
                <a href="/categories">Cancel</a>
            <?php endif; ?>
        </form>

        <!-- List Categories -->
        <h2>All Categories</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Color</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($categories)): ?>
                    <tr>
                        <td colspan="4">No categories found.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($categories as $category): ?>
                        <tr>
                            <td><?= $category['id'] ?></td>
                            <td><?= $category['name'] ?></td>
                            <td><span class="color-preview" style="background-color: <?= $category['color'] ?>;"></span> <?= $category['color'] ?></td>
                            <td>
                                <a href="/categories?id=<?= $category['id'] ?>">Edit</a>
                                <a href="/categories/delete?id=<?= $category['id'] ?>" onclick="return confirm('Are you sure you want to delete this category?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
