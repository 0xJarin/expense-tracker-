<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
        }
        .header {
            background-color: #4CAF50;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 {
            margin: 0;
        }
        .header a {
            color: white;
            text-decoration: none;
            background: #333;
            padding: 10px 15px;
            border-radius: 5px;
        }
        .header a:hover {
            background: #555;
        }
        .dashboard-container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 0 20px;
        }
        .stats {
            display: flex;
            justify-content: space-around;
            margin: 20px 0;
        }
        .stats div {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
            flex: 1;
            margin: 0 10px;
        }
        .stats div h2 {
            margin: 0;
            color: #4CAF50;
        }
        .links {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            margin: 20px 0;
        }
        .links a {
            display: flex;
            align-items: center;
            justify-content: center;
            background: #4CAF50;
            color: white;
            text-decoration: none;
            padding: 15px;
            width: 200px;
            margin: 10px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            font-size: 16px;
        }
        .links a:hover {
            background: #45a049;
        }
        .links a i {
            margin-right: 10px;
        }
        .chart-container {
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .recent-expenses {
            margin-top: 40px;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .recent-expenses h2 {
            margin-top: 0;
        }
        .recent-expenses ul {
            list-style-type: none;
            padding: 0;
        }
        .recent-expenses ul li {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        .recent-expenses ul li:last-child {
            border-bottom: none;
        }
        .recent-expenses {
            margin-top: 40px;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .recent-expenses h2 {
            margin-top: 0;
            text-align: center;
            color: #4CAF50;
        }
        .recent-expenses table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        .recent-expenses th, .recent-expenses td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        .recent-expenses th {
            background-color: #4CAF50;
            color: white;
        }
        .recent-expenses tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .recent-expenses tbody tr:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1><?= ucfirst($data['role']) ?> Dashboard</h1>
        <a href="/logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <div class="dashboard-container">
        <!-- Statistics Section -->
        <div class="stats">
            <?php if ($data['role'] === 'admin'): ?>
                <div>
                    <h2><?= $data['totalUsers'] ?></h2>
                    <p><i class="fas fa-user-shield"></i> Total Users</p>
                </div>
            <?php endif; ?>
            <div>
                <h2><?= $data['totalCategories'] ?></h2>
                <p><i class="fas fa-list-alt"></i> Total Categories</p>
            </div>
            <div>
                <h2>¥<?= number_format($data['totalExpenses'], 2) ?></h2>
                <p><i class="fas fa-chart-pie"></i> Total Expenses</p>
            </div>
        </div>

        <!-- Quick Links Section -->
        <div class="links">
            <?php if ($data['role'] === 'admin'): ?>
                <a href="/users"><i class="fas fa-user-edit"></i> Manage Users</a>
            <?php endif; ?>
            <a href="/categories"><i class="fas fa-tags"></i> Manage Categories</a>
            <a href="/expenses"><i class="fas fa-wallet"></i> Manage Expenses</a>
            <a href="/export"><i class="fas fa-file-download"></i> Export Data</a>
        </div>

        <!-- Chart Section -->
        <div class="chart-container">
            <h2 style="text-align: center;">Expenses by Category</h2>
            <div id="expensesChart"></div>
        </div>

        <div class="recent-expenses">
            <h2>Recent Expenses</h2>
            <?php if (!empty($data['recentExpenses'])): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Amount</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($data['recentExpenses'] as $expense): ?>
                            <tr>
                                <td><?= htmlspecialchars($expense['transaction_date']) ?></td>
                                <td>¥<?= htmlspecialchars(number_format($expense['amount'], 2)) ?></td>
                                <td><?= htmlspecialchars($expense['description']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No recent expenses found.</p>
            <?php endif; ?>
        </div>

    </div>

    <script>
    const chartData = <?= json_encode($data['chartData'] ?? []) ?>;
    const categories = chartData.map(item => item.name);
    const amounts = chartData.map(item => item.amount);

    // Generate random colors
    const colors = categories.map(() => {
        const randomColor = `#${Math.floor(Math.random() * 16777215).toString(16)}`;
        return randomColor.length === 7 ? randomColor : randomColor + "0"; // Ensure valid hex length
    });

    const options = {
        series: [{
            name: 'Expenses (¥)',
            data: amounts
        }],
        chart: {
            type: 'bar',
            height: 350
        },
        colors: colors, // Apply random colors to each bar
        xaxis: {
            categories: categories
        },
        tooltip: {
            y: {
                formatter: val => `¥${val.toFixed(2)}`
            }
        },
        title: {
            text: 'Expenses Breakdown',
            align: 'center',
            style: {
                fontSize: '20px',
                fontWeight: 'bold',
                color: '#333'
            }
        }
    };

    const chart = new ApexCharts(document.querySelector("#expensesChart"), options);
    chart.render();
</script>

</body>
</html>
