<?php
require_once '../config/config.php';
require_once '../controllers/UserController.php';
require_once '../controllers/DashboardController.php';
require_once '../controllers/CategoryController.php';
require_once '../controllers/ExpenseController.php';
require_once '../controllers/ExportController.php';
require_once '../models/ExportLog.php';

session_start();

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// Helper Functions
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['role']);
}

function isAdmin() {
    return isLoggedIn() && $_SESSION['role'] === 'admin';
}

function redirectTo($path) {
    header("Location: $path");
    exit();
}

// Public Routes
$publicRoutes = ['/login', '/register', '/login_submit', '/register_submit'];
if (!in_array($uri, $publicRoutes) && !isLoggedIn()) {
    redirectTo('/login');
}

// Routing Logic
switch ($uri) {
    // Authentication Routes
    case '/login':
        (new UserController())->showLogin();
        break;

    case '/register':
        (new UserController())->showRegister();
        break;

    case '/login_submit':
        (new UserController())->login();
        break;

    case '/register_submit':
        (new UserController())->register();
        break;

    case '/logout':
        session_destroy();
        redirectTo('/login');
        break;

    // Dashboard Route
    case '/dashboard':
        (new DashboardController())->showDashboard();
        break;

    // User Management Routes (Admin Only)
    case '/users':
    case '/users/add':
    case '/users/store':
    case '/users/edit':
    case '/users/update':
    case '/users/delete':
        if (!isAdmin()) redirectTo('/dashboard');
        $userController = new UserController();
        switch ($uri) {
            case '/users': $userController->listUsers(); break;
            case '/users/add': $userController->addUser(); break;
            case '/users/store': $userController->storeUser(); break;
            case '/users/edit': $userController->editUser(); break;
            case '/users/update': $userController->updateUser(); break;
            case '/users/delete': $userController->deleteUser(); break;
        }
        break;

    // Category Management Routes
    case '/categories':
    case '/categories/add':
    case '/categories/store':
    case '/categories/edit':
    case '/categories/update':
    case '/categories/delete':
        $categoryController = new CategoryController();
        switch ($uri) {
            case '/categories': $categoryController->listCategories(); break;
            case '/categories/add': $categoryController->addCategory(); break;
            case '/categories/store': $categoryController->storeCategory(); break;
            case '/categories/edit': $categoryController->editCategory(); break;
            case '/categories/update': $categoryController->updateCategory(); break;
            case '/categories/delete': $categoryController->deleteCategory(); break;
        }
        break;

    // Expense Management Routes
    case '/expenses':
    case '/expenses/store':
    case '/expenses/update':
    case '/expenses/delete':
        $expenseController = new ExpenseController();
        switch ($uri) {
            case '/expenses': $expenseController->listExpenses(); break;
            case '/expenses/store': $expenseController->storeExpense(); break;
            case '/expenses/update': $expenseController->updateExpense(); break;
            case '/expenses/delete': $expenseController->deleteExpense(); break;
        }
        break;

    // Export Routes
    case '/export':
        $controller = new ExportController();
        $exportLogs = isAdmin()
            ? ExportLog::getAllLogs()
            : ExportLog::getUserLogs($_SESSION['user_id']);
        require '../views/export.php';
        break;

    case '/export/csv':
        (new ExportController())->export('CSV');
        break;

    case '/export/pdf':
        (new ExportController())->export('PDF');
        break;

    // Default Route for Undefined Paths
    default:
        if (isLoggedIn()) {
            redirectTo('/dashboard');
        } else {
            http_response_code(404);
            echo "404 - Page Not Found";
        }
        break;
}
