<?php
require_once '../config/config.php';

class Category {
    private $userId;
    private $name;
    private $color;

    public function __construct($userId, $name, $color) {
        $this->userId = $userId;
        $this->name = $name;
        $this->color = $color;
    }

    // Save a new category to the database
    public function save() {
        global $pdo;
        $stmt = $pdo->prepare("INSERT INTO categories (user_id, name, color) VALUES (:user_id, :name, :color)");
        return $stmt->execute([
            ':user_id' => $this->userId,
            ':name' => $this->name,
            ':color' => $this->color
        ]);
    }

    // Get the total count of all categories
    public static function getTotalCategories() {
        global $pdo;
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM categories WHERE deleted_at IS NULL");
        return $stmt->fetch()['total'];
    }

    // Get the count of categories for a specific user
    public static function getUserCategoriesCount($userId) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM categories WHERE user_id = :user_id AND deleted_at IS NULL");
        $stmt->execute([':user_id' => $userId]);
        return $stmt->fetch()['total'];
    }

    // Get all categories
    public static function getAllCategories() {
        global $pdo;
        $stmt = $pdo->query("SELECT * FROM categories WHERE deleted_at IS NULL");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get all categories for a specific user
    public static function getUserCategories($userId) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM categories WHERE user_id = :user_id AND deleted_at IS NULL");
        $stmt->execute([':user_id' => $userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Find a category by ID
    public static function findById($id) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = :id AND deleted_at IS NULL");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Find a category by ID and user
    public static function findByIdAndUser($id, $userId) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = :id AND user_id = :user_id AND deleted_at IS NULL");
        $stmt->execute([':id' => $id, ':user_id' => $userId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Update an existing category
    public static function update($id, $name, $color) {
        global $pdo;
        $stmt = $pdo->prepare("UPDATE categories SET name = :name, color = :color, updated_at = CURRENT_TIMESTAMP WHERE id = :id");
        return $stmt->execute([
            ':id' => $id,
            ':name' => $name,
            ':color' => $color
        ]);
    }

    // Soft delete a category
    public static function delete($id) {
        global $pdo;
        $stmt = $pdo->prepare("UPDATE categories SET deleted_at = CURRENT_TIMESTAMP WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }
}
?>
