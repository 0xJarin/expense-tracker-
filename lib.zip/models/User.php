<?php
require_once '../config/config.php';

class User {
    private $username;
    private $email;
    private $password;
    private $role;

    public function __construct($username, $email, $password, $role) {
        $this->username = $username;
        $this->email = $email;
        $this->password = $password;
        $this->role = $role;
    }

    // Save a new user to the database
    public function save() {
        global $pdo;
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (:username, :email, :password, :role)");
        return $stmt->execute([
            ':username' => $this->username,
            ':email' => $this->email,
            ':password' => $this->password,
            ':role' => $this->role
        ]);
    }

    // Find a user by username
    public static function findByUsername($username) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username AND deleted_at IS NULL");
        $stmt->execute([':username' => $username]);
        return $stmt->fetch(PDO::FETCH_ASSOC); // Returns false if no match
    }
    

    // Find a user by ID
    public static function findById($id) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id AND deleted_at IS NULL");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Get all users
    public static function getAllUsers() {
        global $pdo;
        $stmt = $pdo->query("SELECT id, username, email, role FROM users WHERE deleted_at IS NULL");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Update an existing user
    public static function update($id, $username, $email, $role) {
        global $pdo;
        $stmt = $pdo->prepare("UPDATE users SET username = :username, email = :email, role = :role, updated_at = CURRENT_TIMESTAMP WHERE id = :id");
        return $stmt->execute([
            ':id' => $id,
            ':username' => $username,
            ':email' => $email,
            ':role' => $role
        ]);
    }

    // Soft delete a user
    public static function delete($id) {
        global $pdo;
        $stmt = $pdo->prepare("UPDATE users SET deleted_at = CURRENT_TIMESTAMP WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }

    // Restore a soft-deleted user
    public static function restore($id) {
        global $pdo;
        $stmt = $pdo->prepare("UPDATE users SET deleted_at = NULL WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }

    // Count total users
    public static function getTotalUsers() {
        global $pdo;
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM users WHERE deleted_at IS NULL");
        return $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    }

    // Additional utility functions for `categories` (if required for user scope)
    public static function getTotalCategories() {
        global $pdo;
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM categories WHERE deleted_at IS NULL");
        return $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    }

    public static function getUserCategoriesCount($userId) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM categories WHERE user_id = :user_id AND deleted_at IS NULL");
        $stmt->execute([':user_id' => $userId]);
        return $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    }
}
?>
