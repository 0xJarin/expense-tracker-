<?php
require_once '../config/config.php';

class ExportLog {
    private $userId;
    private $format;

    public function __construct($userId, $format) {
        $this->userId = $userId;
        $this->format = $format;
    }

    // Save export log
    public function save() {
        global $pdo;
        $stmt = $pdo->prepare("INSERT INTO export_logs (user_id, format) VALUES (:user_id, :format)");
        return $stmt->execute([
            ':user_id' => $this->userId,
            ':format' => $this->format
        ]);
    }

    // Get all export logs (admin view)
    public static function getAllLogs() {
        global $pdo;
        $stmt = $pdo->query("SELECT l.id, u.username, l.format, l.export_date 
                             FROM export_logs l 
                             JOIN users u ON l.user_id = u.id 
                             ORDER BY l.export_date DESC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get export logs for a specific user
    public static function getUserLogs($userId) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT id, format, export_date 
                               FROM export_logs 
                               WHERE user_id = :user_id 
                               ORDER BY export_date DESC");
        $stmt->execute([':user_id' => $userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
