<?php
require_once '../config/config.php';

class Expense {
    private $userId;
    private $categoryId;
    private $amount;
    private $description;
    private $transactionDate;

    public function __construct($userId, $categoryId, $amount, $description, $transactionDate) {
        $this->userId = $userId;
        $this->categoryId = $categoryId;
        $this->amount = $amount;
        $this->description = $description;
        $this->transactionDate = $transactionDate;
    }

    public function save() {
        global $pdo;
        $stmt = $pdo->prepare("INSERT INTO transactions (user_id, category_id, amount, description, transaction_date) 
                               VALUES (:user_id, :category_id, :amount, :description, :transaction_date)");
        return $stmt->execute([
            ':user_id' => $this->userId,
            ':category_id' => $this->categoryId,
            ':amount' => $this->amount,
            ':description' => $this->description,
            ':transaction_date' => $this->transactionDate
        ]);
    }

    public static function getTotalExpenses($isAdmin = false, $userId = null) {
        global $pdo;
        if ($isAdmin) {
            $stmt = $pdo->query("SELECT COUNT(*) as total FROM transactions WHERE deleted_at IS NULL");
        } else {
            $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM transactions WHERE user_id = :user_id AND deleted_at IS NULL");
            $stmt->execute([':user_id' => $userId]);
        }
        return $stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
    }

    public static function getTotalExpensesAmount($isAdmin = false, $userId = null) {
        global $pdo;
        if ($isAdmin) {
            $stmt = $pdo->query("SELECT SUM(amount) as total FROM transactions WHERE deleted_at IS NULL");
        } else {
            $stmt = $pdo->prepare("SELECT SUM(amount) as total FROM transactions WHERE user_id = :user_id AND deleted_at IS NULL");
            $stmt->execute([':user_id' => $userId]);
        }
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['total'] ? floatval($result['total']) : 0.00; // Ensure float consistency
    }

    public static function getUserExpensesCount($userId) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM transactions WHERE user_id = :user_id AND deleted_at IS NULL");
        $stmt->execute([':user_id' => $userId]);
        return $stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
    }

    public static function getUserRecentExpenses($userId, $limit = 5) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM transactions WHERE user_id = :user_id AND deleted_at IS NULL ORDER BY transaction_date DESC LIMIT :limit");
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: []; // Return an empty array if no results
    }
    

    public static function getExpensesByCategory($userId, $categoryId) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM transactions WHERE user_id = :user_id AND category_id = :category_id AND deleted_at IS NULL");
        $stmt->execute([':user_id' => $userId, ':category_id' => $categoryId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function getAllExpenses() {
        global $pdo;
        $stmt = $pdo->query("SELECT * FROM transactions WHERE deleted_at IS NULL");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function getUserExpenses($userId) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM transactions WHERE user_id = :user_id AND deleted_at IS NULL");
        $stmt->execute([':user_id' => $userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function findById($id) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM transactions WHERE id = :id AND deleted_at IS NULL");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function findByIdAndUser($id, $userId) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM transactions WHERE id = :id AND user_id = :user_id AND deleted_at IS NULL");
        $stmt->execute([':id' => $id, ':user_id' => $userId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function update($id, $categoryId, $amount, $description, $transactionDate) {
        global $pdo;
        $stmt = $pdo->prepare("UPDATE transactions SET category_id = :category_id, amount = :amount, 
                               description = :description, transaction_date = :transaction_date, 
                               updated_at = CURRENT_TIMESTAMP WHERE id = :id");
        return $stmt->execute([
            ':id' => $id,
            ':category_id' => $categoryId,
            ':amount' => $amount,
            ':description' => $description,
            ':transaction_date' => $transactionDate
        ]);
    }

    public static function delete($id) {
        global $pdo;
        $stmt = $pdo->prepare("UPDATE transactions SET deleted_at = CURRENT_TIMESTAMP WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }

    public static function getExpensesGroupedByCategory($isAdmin = false, $userId = null) {
        global $pdo;
        if ($isAdmin) {
            $stmt = $pdo->query("SELECT c.name AS name, c.color AS color, SUM(t.amount) AS amount
                                 FROM transactions t
                                 LEFT JOIN categories c ON t.category_id = c.id
                                 WHERE t.deleted_at IS NULL
                                 GROUP BY t.category_id");
        } else {
            $stmt = $pdo->prepare("SELECT c.name AS name, c.color AS color, SUM(t.amount) AS amount
                                    FROM transactions t
                                    LEFT JOIN categories c ON t.category_id = c.id
                                    WHERE t.user_id = :user_id AND t.deleted_at IS NULL
                                    GROUP BY t.category_id");
            $stmt->execute([':user_id' => $userId]);
        }
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    public static function getUserExpensesGroupedByCategory($userId) {
        global $pdo;
        $stmt = $pdo->prepare("
            SELECT c.name AS name, c.color AS color, SUM(t.amount) AS amount
            FROM transactions t
            LEFT JOIN categories c ON t.category_id = c.id
            WHERE t.user_id = :user_id AND t.deleted_at IS NULL
            GROUP BY t.category_id
        ");
        $stmt->execute([':user_id' => $userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    public static function countByCategory($categoryId) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM transactions WHERE category_id = :category_id AND deleted_at IS NULL");
        $stmt->execute([':category_id' => $categoryId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] ?? 0; // Return 0 if no transactions found
    }
    
}
?>
